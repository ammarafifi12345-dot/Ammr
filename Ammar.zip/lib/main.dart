import 'package:flutter/material.dart';

void main() => runApp(AmmarApp());

class AmmarApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'عَمّار',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
        primaryColor: Color(0xFFD4AF37),
      ),
      home: SplashScreen(),
    );
  }
}

// شاشة البداية - الصورة رقم 6
class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text('عَمّار', style: TextStyle(color: Color(0xFFD4AF37), fontSize: 60, fontWeight: FontWeight.bold, fontFamily: 'Amiri')),
          Text('AMMAR', style: TextStyle(color: Color(0xFFD4AF37), letterSpacing: 5)),
          SizedBox(height: 30),
          Text('السلام عليكم ورحمة الله وبركاته،\nأهلاً بك في تطبيق عَمّار، كيف تحب أن نناديك؟', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFFD4AF37))),
          SizedBox(height: 20),
          Padding(padding: EdgeInsets.all(20), child: TextField(decoration: InputDecoration(hintText: 'اكتب اسمك هنا', hintStyle: TextStyle(color: Colors.white54), border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)), prefixIcon: Icon(Icons.person, color: Color(0xFFD4AF37))))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF2E7D32), minimumSize: Size(300, 50)),
            onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomeScreen())),
            child: Text('ابدأ رحلتك مع عَمّار', style: TextStyle(fontSize: 18)),
          ),
        ]),
      ),
    );
  }
}

// الرئيسية - الصورة رقم 5
class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(children: [
        SizedBox(height: 60),
        Text('عَمّار', style: TextStyle(color: Color(0xFFD4AF37), fontSize: 45, fontWeight: FontWeight.bold)),
        Text('AMMAR', style: TextStyle(color: Color(0xFFD4AF37), letterSpacing: 6)),
        SizedBox(height: 20),
        Text('السلام عليكم\nأهلاً بك، حان وقت الذكر', textAlign: TextAlign.center, style: TextStyle(color: Colors.white)),
        SizedBox(height: 20),
        Expanded(child: GridView.count(crossAxisCount: 2, padding: EdgeInsets.all(16), children: [
          _card(context, 'صلاتي', 'أوقات الصلاة اليوم', Icons.mosque, SalatyScreen()),
          _card(context, 'دعائي', 'أدعية الصباح والمساء', Icons.front_hand, AzkariScreen()),
          _card(context, 'وردي + الحصري', 'الورد اليومي + سورة الحصري', Icons.menu_book, WirdiScreen()),
          _card(context, 'تسابيحي', 'عداد التسبيح', Icons.circle, TasabihScreen()),
        ])),
      ]),
      bottomNavigationBar: _bottomNav(0),
    );
  }
  Widget _card(BuildContext ctx, String t, String d, IconData icon, Widget go) {
    return GestureDetector(onTap: () => Navigator.push(ctx, MaterialPageRoute(builder: (_) => go)),
      child: Container(margin: EdgeInsets.all(8), decoration: BoxDecoration(color: Color(0xFF1A1A1A), border: Border.all(color: Color(0xFFD4AF37)), borderRadius: BorderRadius.circular(15)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: Color(0xFFD4AF37), size: 35),
          SizedBox(height: 10),
          Text(t, style: TextStyle(color: Color(0xFFD4AF37), fontWeight: FontWeight.bold)),
          Text(d, style: TextStyle(color: Colors.white70, fontSize: 10), textAlign: TextAlign.center),
        ]))));
  }
}

// صلاتي - الصورة اللي انت بعتها أخر حاجة
class SalatyScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black, title: Text('صلاتي', style: TextStyle(color: Color(0xFFD4AF37), fontSize: 28, fontWeight: FontWeight.bold)), centerTitle: true, leading: BackButton(color: Color(0xFFD4AF37)), actions: [Icon(Icons.settings, color: Color(0xFFD4AF37))]),
      body: Padding(padding: EdgeInsets.all(16), child: Column(children: [
        Text('١٤ جمادى الأولى ١٤٤٦ هـ - ١٧ نوفمبر ٢٠٢٤', style: TextStyle(color: Color(0xFFD4AF37), fontSize: 12)),
        SizedBox(height: 8),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.location_on, color: Color(0xFFD4AF37), size: 16), Text(' مكة المكرمة، المملكة العربية السعودية', style: TextStyle(color: Colors.white70))]),
        SizedBox(height: 20),
        Container(padding: EdgeInsets.all(20), decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Color(0xFFD4AF37), width: 2)), child: Column(children: [Text('القبلة', style: TextStyle(color: Colors.white)), Icon(Icons.cabin, color: Color(0xFFD4AF37)), Text('شمال شرق 127°', style: TextStyle(color: Color(0xFFD4AF37)))])),
        SizedBox(height: 10),
        Text('وجه نحو الكعبة من موقعك الحالي', style: TextStyle(color: Colors.white54, fontSize: 12)),
        SizedBox(height: 20),
        Align(alignment: Alignment.centerRight, child: Text('مواقيت الصلاة', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold))),
        _prayerRow('الفجر', '05:12', Icons.nights_stay, false),
        _prayerRow('الظهر', '12:05', Icons.wb_sunny, false),
        _prayerRow('العصر • الصلاة القادمة', '15:32', Icons.cloud, true),
        _prayerRow('المغرب', '17:55', Icons.wb_twilight, false),
        _prayerRow('العشاء', '19:20', Icons.star, false),
      ])),
      bottomNavigationBar: _bottomNav(0),
    );
  }
  Widget _prayerRow(String name, String time, IconData icon, bool active) {
    return Container(margin: EdgeInsets.only(top: 8), padding: EdgeInsets.all(14), decoration: BoxDecoration(border: Border.all(color: active ? Color(0xFFD4AF37) : Colors.white24), borderRadius: BorderRadius.circular(10), color: active ? Color(0xFF1A1A1A) : Colors.transparent),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(name, style: TextStyle(color: active ? Color(0xFFD4AF37) : Colors.white)), Row(children: [Icon(icon, color: Color(0xFFD4AF37), size: 18), SizedBox(width: 6), Text(time, style: TextStyle(color: Color(0xFFD4AF37), fontWeight: FontWeight.bold))])]));
  }
}

// باقي الشاشات (أذكاري - تسابيحي - وردي - أسماء الله)
class AzkariScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.black, appBar: AppBar(backgroundColor: Colors.black, title: Text('أذكاري', style: TextStyle(color: Color(0xFFD4AF37), fontSize: 28)), centerTitle: true, leading: BackButton(color: Color(0xFFD4AF37)), actions: [Icon(Icons.search, color: Color(0xFFD4AF37))]),
      body: ListView(padding: EdgeInsets.all(16), children: [
        Center(child: Text('اختر الذكر المناسب ليومك\nحصّن يومك بالأذكار الصحيحة من القرآن والسنة', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFFD4AF37)))),
        SizedBox(height: 20),
        _azkarCard('أذكار الصباح', 'تقال بعد صلاة الفجر • 33 ذكراً', '33/33', 'مكتمل'),
        _azkarCard('أذكار المساء', 'تقال بعد صلاة العصر • 33 ذكراً', '18/33', 'قيد التقدم'),
        _azkarCard('أذكار النوم', 'تقال قبل النوم • 11 ذكراً', '0/11', 'لم يبدأ'),
      ]), bottomNavigationBar: _bottomNav(4));
  }
  Widget _azkarCard(String t, String d, String num, String status) {
    return Container(margin: EdgeInsets.only(bottom: 12), padding: EdgeInsets.all(16
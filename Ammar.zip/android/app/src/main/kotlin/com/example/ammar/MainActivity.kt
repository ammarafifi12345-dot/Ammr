package com.example.ammar

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
